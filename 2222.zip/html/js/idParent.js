function parent(id){
  var du=window.opener;
  var.num='1';

  du.documnet.userinput.use.value=num;
  du.id.value=id;

  self.close();
}
