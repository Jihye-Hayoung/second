<?php
$host='localhost';
$dbid="root";
$dbpw="root";
$dbname="hufsgo";
 ?>
