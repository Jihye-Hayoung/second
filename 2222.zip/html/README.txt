# numero-html
HTML version of Numero
Designed by Devfloat.net

#License
Free for using on your website or client projects. 
Please dont sell this template as we already have a premium wordpress version. Get it if you want it. :)